package com.manuelsenatore.AppMessage.AppMessage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppMessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
